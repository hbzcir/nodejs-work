var express = require('express');
var bodyParser = require('body-parser');
var fs = require('fs');
var mysql      = require('mysql');
var conn = mysql.createConnection({
  host     : 'localhost',
  user     : 'root',
  password : '12qwas',
  database : 'o2'
});
conn.connect();
var app = express();
app.use(bodyParser.urlencoded({extended: false})); //post로 들어오는 리퀘스트를 
app.locals.pretty = true;
app.set('views','./views_file'); //템플릿엔진의 파일들은 views , ./views_file 경로지정
app.set('view engine', 'jade'); //npm jade install 후 --> jade 사용설정 구문
app.get('/topic/add', function(req,res){ //글 작성할때
    res.render('new');
})

app.get('/topic/',function(req,res){
    var sql = 'SELECT * FROM topic';
    conn.query(sql, function(err, topics, fields){
      res.render('list',{topics:topics})  
    });
})

// view 
app.get(['/topic', '/topic/:id'],function(req,res){
    var listId = req.params.id;
    // var sqlView = 'SELECT * FROM topic WHERE '+'id'+' IN ('+listId+')';
    var sqlView = 'SELECT * FROM topic WHERE '+'id'+' IN ('+listId+')';
    conn.query(sqlView, function(err, topics, fields){
      res.render('view',{topics:topics});
          var sql = 'SELECT * FROM comment_table WHERE '+'boardCode'+' IN ('+listId+')';
          conn.query(sql, function(err, cmts, fields){
            // res.render('view',{cmts:cmts})
          });
    });

    // var sql = 'SELECT * FROM comment_table WHERE '+'boardCode'+' IN ('+listId+')';
    // conn.query(sql, function(err, cmts, fields){
    //   res.render('view',{cmts:cmts})
    // });
})

//  var sql = 'SELECT id, title FROM topic';
//     conn.query(sql, function(err, topics, feilds){
//         //res.send(rows);
//         var id = req.params.id;
//         if(id){
//             var sql = 'SELECT * FROM topic WHERE id=?';
//             conn.query(sql, [id], function(err, topic, fields){
//                 if(err){
//                     console.log(err);
//                     res.status(500).send('Internal Server Error');
//                 }else{
//                     res.render('view', {topics:topics, topic:topic[0]});
//                 }
//             }) 
//         }else {
//             res.render('view', {topics:topics});
//         }
//     })

// Write
// app.post('/topic', function(req, res){
//     var name = req.body.name;
//     var title = req.body.title;
//     var description = req.body.description;
//     fs.writeFile('data/'+title, description, function(err){
//         if(err){
//             console.log(err);
//             res.status(500).send('interal server error');
//         }
//         res.send('success');
//     });
// });


app.listen(3000, function(){ 
    console.log('connected 3000 port')
})